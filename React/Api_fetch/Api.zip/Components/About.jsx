import React from 'react'

const About = () => {
  return (
    <div className='home'>About</div>
  )
}

export default About