const HeaderData = [
    {
        title:"Home",
        href:"/"
    },
    {
        title:"About",
        href:"/about"
    },
    {
        title:"SignUp",
        href:"/signup"
    },
    {
        title:"Items",
        href:"/items"
    },
]

export default HeaderData;