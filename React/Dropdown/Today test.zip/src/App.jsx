import React from "react";
import Dropdown from "./Dropdown";
import ApiFetching from "./ApiFetching";

const App = () => {
  return (
    <>
    <div style={{width:"100%", height:"10vh", margin:"30px 400px" }}>
      <Dropdown />

    </div>
      <ApiFetching />
    </>
  );
};

export default App;
